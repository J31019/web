import { Component, OnInit } from '@angular/core';
import { FakeRequestService } from '../services/fake.service';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.scss']
})
export class MenuComponent implements OnInit {
  categories = [];

  showItems(event) {
    this.requestService.getItems(event.option.value).toPromise().then(
      (data: any) => {
        console.log(data);
      }
    );
  }

  constructor(private requestService: FakeRequestService) {
    this.requestService.getCategories().toPromise().then(
      (data: any) => {
        this.categories = data;
      },
      (err) => {
        console.log(err);
      },
    );
  }

  ngOnInit() {
  }

}
