export const environment = {
  production: false,
  api_url: ""
};
